const TheSimplestReactComponent = () => {
    return React.createElement("h1",  {id: "id123"}, "Hello, World! React Component from a separate module file." ); 
}

export default TheSimplestReactComponent;
