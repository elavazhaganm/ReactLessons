const SampleTableComponent = () => {
  const data = [
    { id: "1", name: "A", age: 10 },
    { id: "2", name: "B", age: 11 },
    { id: "3", name: "C", age: 12 },
  ];

  const tableRows = data.map((rowData) => (
    <tr key={rowData.id}>
      {Object.values(rowData).map((cellData, index) => (
        <td key={index}>{cellData}</td>
      ))}
    </tr>
  ));

  return (
    <table border="1">
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Age</th>
        </tr>
      </thead>
      <tbody>{tableRows}</tbody>
    </table>
  );
};

export default SampleTableComponent;
