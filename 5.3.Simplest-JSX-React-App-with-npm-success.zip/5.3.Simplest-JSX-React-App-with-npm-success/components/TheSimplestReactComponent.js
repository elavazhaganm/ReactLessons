console.log("components/TheSimplestReactComponent.js... Loaded");

import React from "react";

const TheSimplestReactComponent = () => {
  console.log("TheSimplestReactComponent() called...");
  return <h1 id="id123">"Hello, World from JSX & WebPack!!!"</h1>;
};

export default TheSimplestReactComponent;
