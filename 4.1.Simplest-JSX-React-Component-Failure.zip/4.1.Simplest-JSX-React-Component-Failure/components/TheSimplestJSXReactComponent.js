const TheSimplestJSXReactComponent = () => {
  //return React.createElement("h1",  {id: "id123"}, "Hello, World! React Component from a separate module file." );
  return (
    <h1 id="123">
      "Hello, World! JSX React Component from a separate module file."
    </h1>
  );
};

export default TheSimplestJSXReactComponent;
