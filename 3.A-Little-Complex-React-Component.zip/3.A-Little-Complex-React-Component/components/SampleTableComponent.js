const SampleTableComponent = () => {
  const data = [
    { id: "1", name: "A", age: 10 },
    { id: "2", name: "B", age: 11 },
    { id: "3", name: "C", age: 12 },
  ];
  return React.createElement(
    "table",
    { border: "1" },
    React.createElement(
      "thead",
      null,
      React.createElement(
        "tr",
        null,
        React.createElement("th", null, "ID"),
        React.createElement("th", null, "Name"),
        React.createElement("th", null, "Age")
      )
    ),
    React.createElement(
      "tbody",
      null,
      data.map((rowData) => {
        const rowCells = Object.values(rowData).map((cellData, index) =>
          React.createElement("td", { key: index }, cellData)
        );
        return React.createElement("tr", { key: rowData.id }, rowCells);
      })
    )
  );
};

export default SampleTableComponent;
