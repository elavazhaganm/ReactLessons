console.log("./index.js... Loaded");

import ReactDOM from "react-dom";
import TheSimplestReactComponent from "./components/TheSimplestReactComponent.js";

const parentDivElement = document.getElementById("parentDiv");
const reactRoot = ReactDOM.createRoot(parentDivElement);
reactRoot.render(TheSimplestReactComponent());
